import java.sql.*;
import java.util.*;



public class myMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		/* All variables we will need to execute queries to the Database */
		String url = "jdbc:mysql://localhost:3306/covbase"; // instead of covbase you can swap for the name of your database
		Connection connection = null;
		Statement statement = null; // it contains the SQL query which will be sent to the Database
		ResultSet rs = null; // it contains "answers" for the above statement
		
		/* Credentials for MySQL Database */
		String uname = "root";
		String pass = "";
		
		/* Connection creation using the above credentials */
		Class.forName("com.mysql.jdbc.Driver");
		connection = DriverManager.getConnection(url,uname,pass); // making the connection to MySQL Database
		
		int option = -1; // main menu selection pointer
		int suboption = -1; // submenu selection pointer
		Scanner in = new Scanner(System.in); // scanner type to read from console
		
		System.out.println("Covbase 2020 - by Psarros");
		/* Selection Menu */
		do {
			
			System.out.println("\n\nMain Menu \n");
			System.out.println("Option 1: Create 'publications' table in covbase \n");
			System.out.println("Option 2: Delete/Drop 'publications' table in covbase \n");
			System.out.println("Option 3: Insert data to 'publications' from file (Tip: Replace ,, with ,-1, and take care of the wrongs in author names) \n");
			System.out.println("Option 4: Analytics \n");
			System.out.println("Option 0: Exit \n");
			
			/* standard input read for Main Menu */
			option = in.nextInt();
			
			/* Table creation */
			if(option == 1) {
				
				statement = connection.createStatement();
				boolean created = statement.execute("CREATE TABLE publications (sha VARCHAR(255) DEFAULT NULL, source_x VARCHAR(255) DEFAULT NULL, title VARCHAR(1000) DEFAULT NULL, doi VARCHAR(255) DEFAULT NULL, pmcid VARCHAR(255) DEFAULT NULL, pubmed_id INT DEFAULT NULL, license VARCHAR(255) DEFAULT NULL, abstract MEDIUMTEXT DEFAULT NULL, publish_time VARCHAR(255) DEFAULT NULL, authors TEXT, journal VARCHAR(255) DEFAULT NULL, MAPid BIGINT DEFAULT NULL, who VARCHAR(255) DEFAULT NULL, has_full_text VARCHAR(255) DEFAULT NULL);");
				
				statement.close(); // closing this statement and when we need a new one we will create it
				
				System.out.println("Table 'publications' created succesfully \n");
				
			}else if (option ==2){
				
				statement = connection.createStatement();
				boolean deleted = statement.execute("DROP TABLE publications;");
				
				statement.close(); // closing this statement and when we need a new one we will create it
				
				System.out.println("Table 'publications' deleted/dropped succesfully \n");
				
			}else if (option == 3) {
				
				statement = connection.createStatement();
				rs = statement.executeQuery("LOAD DATA INFILE 'c:/programming/test_import.csv'\r\n" + 
						"INTO TABLE publications \r\n" + 
						"FIELDS TERMINATED BY ',' ENCLOSED BY '\"'\r\n" + 
						"LINES TERMINATED BY '\\n'\r\n" + 
						"IGNORE 1 ROWS\r\n");
				
				statement.close(); // closing this statement and when we need a new one we will create it
				
				System.out.println("Information from .csv file loaded succefully on table 'publications' \n");
				
			}else if (option == 4) {
				
				do {
					
					/* Selection Submenu */
					System.out.println("\nAnalytics Menu \n");
					System.out.println("Option 1: Print the amount of entries in the table \n");
					System.out.println("Option 2: Print all journals where publications were published\n");
					System.out.println("Option 3: Print the amount of publications from specific journal \n");
					System.out.println("Option 4: Print the amount of publications that have full text \n");
					System.out.println("Option 5: Print the title of publications for specific sha \n");
					System.out.println("Option 6: Print the title of publications for specific Microsoft Academic Paper ID\n");
					System.out.println("Option 9: Exit Analytics Menu \n");
					
					/* standard input read for Submenu */
					suboption = in.nextInt();
					
					if (suboption == 1) {
						
						statement = connection.createStatement();
						rs = statement.executeQuery("SELECT COUNT(*) FROM publications;");
						
						rs.next();// To get to the first answer of the result set
						int total_count = rs.getInt(1);// Getting the first answer of the result set's table
						
						System.out.println("The total amount of publications in covbase is: " +total_count+" \n\n\n");
						
						statement.close(); // closing this statement and when we need a new one we will create it
						
					}else if (suboption == 2) {
						
						statement = connection.createStatement();
						rs = statement.executeQuery("SELECT DISTINCT journal FROM publications ORDER BY journal;");
						
						String temp_journal = "";
						int i = 0;
						while (rs.next()) { // doing the condition check and moving the cursor to the next index
							i++; // 
							temp_journal = rs.getString("journal"); // getting the value of the column
							System.out.println(i+". "+temp_journal+"\n");
						}
						
						statement.close(); // closing this statement and when we need a new one we will create it
						
					}else if (suboption == 3) {
						
						System.out.println("Please, type in the exact name of journal \n");
						
						String search = "";
						while (search.isEmpty()) {
							search = in.nextLine(); // Reading from console
						}
						
						statement = connection.createStatement();
						rs = statement.executeQuery("SELECT COUNT(*) FROM publications WHERE STRCMP(publications.journal,\""+search+"\") = 0;");
						
						rs.next(); // To get to the first answer of the result set
						int journal_count = rs.getInt(1); // Getting the first answer of the result set's table
						
						System.out.println("The amount of publications from "+search+" is: " +journal_count+" \n\n\n");
						
						statement.close(); // closing this statement and when we need a new one we will create it
						
						
					}else if (suboption == 4) {
						
						statement = connection.createStatement();
						rs = statement.executeQuery("SELECT COUNT(*) FROM publications WHERE has_full_text = 'TRUE';");
						
						rs.next(); // To get to the first answer of the result set
						int has_full_text_count = rs.getInt(1); // Getting the first answer of the result set's table
						
						System.out.println("The amount of publications that have full text is: " +has_full_text_count+" \n\n\n");
						
						statement.close(); // closing this statement and when we need a new one we will create it
						
					}else if (suboption == 5) {
						
						System.out.println("Please, type in the exact sha \n");
						
						String search = "";
						while (search.isEmpty()) {
							search = in.nextLine(); // Reading from console
						}
						
						statement = connection.createStatement();
						rs = statement.executeQuery("SELECT title FROM publications WHERE STRCMP(publications.sha,\""+search+"\") = 0;");
						
						rs.next(); // To get to the first answer of the result set
						String title = rs.getString(1); // Getting the first answer of the result set's table
						
						System.out.println("The title of publications with sha: "+search+" is: " +title+" \n\n\n");
						
						statement.close(); // closing this statement and when we need a new one we will create it
						
					}else if (suboption == 6) {
						
						System.out.println("Please, type in the exact Microsoft Academic Paper ID \n");
						
						String search = "";
						while (search.isEmpty()) {
							search = in.nextLine(); // Reading from console
						}
						
						statement = connection.createStatement();
						rs = statement.executeQuery("SELECT title FROM publications WHERE STRCMP(publications.MAPid,\""+search+"\") = 0;");
						
						rs.next(); // To get to the first answer of the result set
						String title = rs.getString(1); // Getting the first answer of the result set's table
						
						System.out.println("The title of publications with Microsoft Academic ID: "+search+" is: " +title+" \n\n\n");
						
						statement.close(); // closing this statement and when we need a new one we will create it
						
					}
				
				}while (suboption != 9);
			}
		
		}while (option != 0);
		
		connection.close(); // Closing the connection to the Database, when we finish our business with it
		
		System.out.println("\n\n\nHope we served you good information. Goodbye! \n");

	}

}
